const MAX_FILE_SIZE = 15 * 1024 * 1024;
const GRAPH_API_VERSION = 'v22.0';

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8' }
  });
}

export async function onRequestPost({ request, env }) {
  if (!env.WHATSAPP_TOKEN || !env.WHATSAPP_PHONE_NUMBER_ID) {
    return json({ error: 'Server belum dikonfigurasi. Tambahkan WHATSAPP_TOKEN dan WHATSAPP_PHONE_NUMBER_ID di pengaturan Cloudflare Pages.' }, 503);
  }

  let form;
  try {
    form = await request.formData();
  } catch {
    return json({ error: 'Data formulir tidak valid.' }, 400);
  }

  const phone = String(form.get('phone') || '').replace(/\D/g, '');
  const file = form.get('file');

  if (!/^\d{8,15}$/.test(phone)) {
    return json({ error: 'Nomor tidak valid. Masukkan nomor dengan kode negara, angka saja, contoh 628123456789.' }, 400);
  }
  if (!(file instanceof File) || !file.size) {
    return json({ error: 'Pilih file yang ingin dikirim.' }, 400);
  }
  if (file.size > MAX_FILE_SIZE) {
    return json({ error: 'Ukuran file melewati batas aplikasi 15 MB.' }, 413);
  }

  try {
    const mediaForm = new FormData();
    mediaForm.append('messaging_product', 'whatsapp');
    mediaForm.append('type', file.type || 'application/octet-stream');
    mediaForm.append('file', file, file.name || 'upload.bin');

    const mediaResponse = await fetch(
      `https://graph.facebook.com/${GRAPH_API_VERSION}/${env.WHATSAPP_PHONE_NUMBER_ID}/media`,
      {
        method: 'POST',
        headers: { Authorization: `Bearer ${env.WHATSAPP_TOKEN}` },
        body: mediaForm
      }
    );
    const mediaData = await mediaResponse.json();
    if (!mediaResponse.ok || !mediaData.id) {
      return json({ error: mediaData.error?.message || 'WhatsApp API menolak unggahan file. Periksa token, izin, dan jenis file.' }, 502);
    }

    const sendResponse = await fetch(
      `https://graph.facebook.com/${GRAPH_API_VERSION}/${env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${env.WHATSAPP_TOKEN}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: phone,
          type: 'document',
          document: { id: mediaData.id, filename: file.name || 'file' }
        })
      }
    );
    const sendData = await sendResponse.json();
    if (!sendResponse.ok) {
      return json({ error: sendData.error?.message || 'WhatsApp gagal mengirim pesan. Periksa aturan pesan dan nomor penerima.' }, 502);
    }
    return json({
      ok: true,
      message: 'WhatsApp API menerima permintaan pengiriman.',
      messageId: sendData.messages?.[0]?.id || null
    });
  } catch (error) {
    return json({ error: 'Server tidak dapat menghubungi WhatsApp API. Coba lagi nanti.' }, 502);
  }
}
