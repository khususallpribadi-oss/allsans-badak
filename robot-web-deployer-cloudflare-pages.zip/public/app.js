const phone = document.querySelector('#phone');
const fileInput = document.querySelector('#file');
const sendButton = document.querySelector('#send');
const statusBox = document.querySelector('#status');

phone.addEventListener('input', () => {
  phone.value = phone.value.replace(/\D/g, '').slice(0, 15);
});

function showStatus(message, type = '') {
  statusBox.textContent = message;
  statusBox.className = `status ${type}`.trim();
}

sendButton.addEventListener('click', async () => {
  const number = phone.value.trim();
  const file = fileInput.files[0];
  if (!number || number.length < 8) {
    showStatus('Nomor belum valid. Gunakan kode negara, misalnya 628123456789.', 'error');
    phone.focus(); return;
  }
  if (!file) {
    showStatus('Pilih file yang ingin dikirim terlebih dahulu.', 'error');
    fileInput.focus(); return;
  }
  if (file.size > 15 * 1024 * 1024) {
    showStatus('File terlalu besar. Batas maksimal adalah 15 MB.', 'error'); return;
  }
  const data = new FormData();
  data.append('phone', number);
  data.append('file', file);
  sendButton.disabled = true;
  sendButton.querySelector('span').textContent = 'MENGIRIM...';
  showStatus('Sedang mengirim file melalui server. Mohon tunggu.');
  try {
    const response = await fetch('/api/send', { method: 'POST', body: data });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Pengiriman gagal.');
    showStatus('BERHASIL DIPROSES! ' + result.message, 'success');
  } catch (error) {
    showStatus(error.message || 'Tidak dapat terhubung ke server.', 'error');
  } finally {
    sendButton.disabled = false;
    sendButton.querySelector('span').textContent = 'KIRIM BADAK!';
  }
});
