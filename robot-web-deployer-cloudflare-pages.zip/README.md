# Komik Kirim Badak — Cloudflare Pages

Paket ini dirancang untuk di-deploy sebagai **Cloudflare Pages project**. Halaman statis di folder `public/`; backend berada di `functions/api/send.js` sebagai Pages Function. Tidak perlu server Node.js yang terus menyala: Cloudflare menjalankan fungsi ketika endpoint dipanggil.

## Deploy ke Cloudflare Pages

1. Ekstrak ZIP ini.
2. Upload folder proyek ke repository Git (GitHub/GitLab), termasuk folder `functions`.
3. Di Cloudflare Dashboard buka **Workers & Pages → Create → Pages → Connect to Git** dan pilih repository.
4. Isi konfigurasi build:
   - **Framework preset:** None
   - **Build command:** kosongkan
   - **Build output directory:** `public`
   - **Root directory:** kosong / root repository
5. Deploy. Cloudflare Pages akan melayani file statis dan menjalankan `functions/api/send.js` sebagai endpoint `/api/send`.

Alternatif: gunakan Wrangler CLI dari komputer:
- `npx wrangler pages project create`
- `npx wrangler pages deploy public --project-name NAMA-PROYEK`
  Pastikan folder `functions/` ikut tersedia dalam root proyek untuk build/deploy Pages Functions. Cara paling mudah untuk Functions adalah deploy melalui integrasi Git sesuai langkah di atas atau `wrangler pages deploy` dengan project directory yang berisi `functions/` dan aset publik.

## Atur rahasia API (wajib)

Pada Cloudflare Dashboard → Workers & Pages → proyek Pages Anda → **Settings → Variables and Secrets**:
- Tambahkan secret `WHATSAPP_TOKEN` = access token WhatsApp Cloud API.
- Tambahkan variable `WHATSAPP_PHONE_NUMBER_ID` = Phone Number ID WhatsApp Cloud API.
- Simpan perubahan lalu lakukan redeploy bila diminta.

Jangan menaruh token di HTML/JavaScript atau di repository. Jangan membagikan token kepada siapa pun.

## Persiapan WhatsApp Cloud API

- Buat/konfigurasi aplikasi Meta Developers dan tambahkan produk WhatsApp.
- Ambil access token dan Phone Number ID dari WhatsApp Cloud API.
- Konfigurasikan penerima uji/nomor bisnis dan izin yang diwajibkan Meta.
- Pastikan penerima mengharapkan pesan dan mematuhi kebijakan WhatsApp. Pesan bebas biasanya tunduk pada jendela layanan pelanggan; di luar jendela tersebut, aturan template yang disetujui dapat berlaku. Untuk mengirim dokumen dalam sesi yang diizinkan, backend ini memakai endpoint media dan messages resmi.
- Setelah deploy, tes di URL `https://NAMA-PROYEK.pages.dev`.

## Cara kerja

Browser mengirim nomor dan file ke `/api/send`. Pages Function mengunggah file ke WhatsApp Cloud API, lalu mengirimnya sebagai dokumen. Batas aplikasi adalah 15 MB; batas aktual juga tunduk pada batas tipe/ukuran media WhatsApp. Respons sukses berarti API menerima permintaan, bukan jaminan file telah dibaca penerima.

## Keamanan dan batasan

- Ini adalah starter sederhana; sebelum dipakai publik, tambahkan CAPTCHA/rate limiting atau autentikasi untuk mencegah penyalahgunaan biaya/API.
- Pertimbangkan pembatasan tipe file dan kebijakan privasi.
- Jangan gunakan untuk spam atau mengirim file tanpa persetujuan penerima.
- `public/` adalah direktori aset statis. Jangan menyimpan token rahasia di dalamnya.
